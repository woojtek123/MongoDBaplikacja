const { body, validationResult } = require("express-validator");
const multer = require("multer");
const path = require("path");
const Gallery = require("../models/gallery");
const Image = require("../models/image");
const User = require("../models/user");
const asyncHandler = require("express-async-handler");
const fs = require("fs");
const Comment = require('../models/comment');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/images');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// IMAGE LIST
exports.image_list = asyncHandler(async (req, res, next) => {
  const all_images = await Image.find({}).populate("gallery").exec();
  res.render("image_list", { title: "List of all images:", image_list: all_images });
});

// IMAGE ADD GET
exports.image_add_get = asyncHandler(async (req, res, next) => {
  let opcje;
  let all_galleries;

  if (req.user.username === "admin") {
    all_galleries = await Gallery.find().exec();
    opcje = { "admin_user": true, "disabled": false };
  } else {
    let owner_user = await User.findOne({ "username": req.user.username }).exec();
    all_galleries = await Gallery.find({ user: owner_user._id }).exec();
    opcje = { "admin_user": false, "disabled": true, "owner_user": owner_user };
  }

  res.render("image_form", {
    title: "Add Image",
    galleries: all_galleries,
    opcje: opcje,
  });
});

// IMAGE ADD POST
exports.image_add_post = [
  upload.single('image'),
  body("i_name", "Image name is required.").trim().isLength({ min: 1 }).escape(),
  body("i_description").trim().escape(),
  body("i_gallery", "Gallery must be selected.").trim().isLength({ min: 1 }).escape(),

  asyncHandler(async (req, res, next) => {
    const errors = validationResult(req);

    const { i_name, i_description, i_gallery } = req.body;
    let imagePath = '';

    if (req.file) {
      imagePath = '/images/' + req.file.filename;
    }

    const image = new Image({
      name: i_name,
      description: i_description,
      path: imagePath,
      gallery: i_gallery,
    });

    if (!errors.isEmpty()) {
      let opcje;
      let all_galleries;

      if (req.user.username === "admin") {
        all_galleries = await Gallery.find().exec();
        opcje = { "admin_user": true, "disabled": false };
      } else {
        let owner_user = await User.findOne({ "username": req.user.username }).exec();
        all_galleries = await Gallery.find({ user: owner_user._id }).exec();
        opcje = { "admin_user": false, "disabled": true, "owner_user": owner_user };
      }

      res.render("image_form", {
        title: "Add Image",
        image: image,
        galleries: all_galleries,
        opcje: opcje,
        errors: errors.array(),
      });
      return;
    } else {
      await image.save();
      res.redirect("/images");
    }
  }),
];
// IMAGE DELETE POST
exports.image_delete_post = asyncHandler(async (req, res, next) => {
  console.log("Request to delete image with ID:", req.params.id);
  const imageId = req.params.id;

  // Znajdź i usuń obrazek po ID
  const image = await Image.findByIdAndDelete(imageId);
  if (!image) {
    res.status(404).send('Image not found');
    return;
  }

  //// Usunięcie pliku z systemu plików
 const imagePath = path.join(__dirname, '../public', image.path);
  fs.unlink(imagePath, (err) => {
    if (err) {
      console.error("Failed to delete image file:", err);
    }
 });

  res.redirect('/images');
});
exports.image_edit_get = asyncHandler(async (req, res, next) => {
  const image = await Image.findById(req.params.id).exec();
  if (!image) {
    res.status(404).send('Image not found');
    return;
  }
  const all_galleries = await Gallery.find().exec();
  res.render('image_form', { title: 'Edit Image', image: image, galleries: all_galleries });
});

// Kontroler edycji obrazka - POST
exports.image_edit_post = [
  upload.single('image'),
  body('i_name', 'Image name is required.').trim().isLength({ min: 1 }).escape(),
  body('i_description').trim().escape(),
  body('i_gallery', 'Gallery must be selected.').trim().isLength({ min: 1 }).escape(),

  asyncHandler(async (req, res, next) => {
    const errors = validationResult(req);
    const { i_name, i_description, i_gallery } = req.body;
    let imagePath = '';

    if (req.file) {
      imagePath = '/images/' + req.file.filename;
    }

    const image = await Image.findById(req.params.id).exec();
    if (!image) {
      res.status(404).send('Image not found');
      return;
    }

    image.name = i_name;
    image.description = i_description;
    image.gallery = i_gallery;
    if (imagePath) {
  
      const oldImagePath = path.join(__dirname, '../public', image.path);
      fs.unlink(oldImagePath, (err) => {
        if (err) {
          console.error("Failed to delete old image file:", err);
        }
      });
      image.path = imagePath;
    }

    if (!errors.isEmpty()) {
      const all_galleries = await Gallery.find().exec();
      res.render('image_form', {
        title: 'Edit Image',
        image: image,
        galleries: all_galleries,
        errors: errors.array()
      });
      return;
    } else {
      await image.save();
      res.redirect('/images');
    }
  })
];
exports.image_add_comment = asyncHandler(async (req, res, next) => {
  const imageId = req.params.id;
  const commentText = req.body.comment;
  const authorId = req.user._id; 

  const image = await Image.findById(imageId);
  if (!image) {
    res.status(404).send('Image not found');
    return;
  }

  image.comments = image.comments || []; 
  image.comments.push({ text: commentText, date: new Date(), author: authorId });

  await image.save();
  res.redirect('/images');
});
