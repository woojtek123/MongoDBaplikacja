var express = require('express');
var router = express.Router();
// Import funkcji middleware autentykacji
const authenticate = require('../middleware/authenticate');

const gallery_controller = require("../controllers/galleryController");

// GALLERIES GET (/galleries)
router.get("/", gallery_controller.gallery_list);

// dodanie middleware autentykacji do dodawania galerii
router.get("/gallery_add", authenticate, gallery_controller.gallery_add_get);

// GALLERY ADD POST (/galleries/gallery_add)
router.post("/gallery_add", authenticate, gallery_controller.gallery_add_post);

router.get("/gallery_browse", gallery_controller.gallery_browse);

router.post("/gallery_browse", gallery_controller.gallery_browse);

module.exports = router;
