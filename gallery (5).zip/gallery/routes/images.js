var express = require('express');
var router = express.Router();

const image_controller = require("../controllers/imageController");

const authenticate = require('../middleware/authenticate');


// IMAGES GET (/images)
router.get("/", image_controller.image_list);

//router.get("/", authenticate, image_controller.image_list);
router.get("/image_add", authenticate, image_controller.image_add_get);

// IMAGE ADD POST (/images/image_add)
router.post("/image_add", authenticate, image_controller.image_add_post);

router.post('/images/:id/delete', authenticate, image_controller.image_delete_post);

// Trasa do edycji obrazu - GET
router.get('/images/:id/edit', authenticate, image_controller.image_edit_get);

// Trasa do edycji obrazu - POST
router.post('/images/:id/edit', authenticate, image_controller.image_edit_post);

router.post('/:id/comments', authenticate,  image_controller.image_add_comment);


module.exports = router;
