# Dokumentacja Aplikacji Galerii

## Spis treści

1. **Opis możliwości/funkcji aplikacji**
2. **Lista wykorzystanych pakietów**
3. **Opis interfejsu (ścieżek/API)**
4. **Opis modeli wykorzystywanych w kolekcjach**
5. **Opis konstrukcji aplikacji**
6. **Wykorzystane technologie**

---

## 1. Opis możliwości/funkcji aplikacji

Aplikacja Galerii pozwala użytkownikom na:
- Przeglądanie dostępnych galerii i zdjęć.
- Dodawanie nowych zdjęć do wybranych galerii.
- Usuwanie zdjęć.
- Dodawanie komentarzy pod zdjęciami.

## 2. Lista wykorzystanych pakietów

- **express**: Szybkie i minimalistyczne środowisko aplikacji sieci web dla Node.js.
- **express-validator**: Middleware do walidacji i sanitacji danych przychodzących.
- **multer**: Middleware do obsługi przesyłania plików.
- **mongoose**: Obiektowy model dokumentu MongoDB, który pozwala pracować z MongoDB.
- **express-session**: Middleware do obsługi sesji.
- **method-override**: Middleware do obsługi zapytań PUT i DELETE w formularzach HTML.
- **pug**: Silnik szablonów do renderowania dynamicznych stron HTML.
- **connect-flash**: Middleware do wyświetlania wiadomości (np. błędów, potwierdzeń) pomiędzy zapytaniami.
- **bcryptjs**: Biblioteka do hashowania haseł.

## 3. Opis interfejsu (ścieżek/API)

### Główne ścieżki aplikacji:

- `/`: Strona główna.
- `/users/login`: Logowanie użytkownika.
- `/users/logout`: Wylogowanie użytkownika.
- `/users/register`: Rejestracja nowego użytkownika.

### Ścieżki związane z obrazkami:

- `/images`: Przeglądanie listy obrazków.
- `/images/add`: Formularz dodawania nowego obrazka.
- `/images/:id/comments`: Dodawanie komentarza do obrazka.
- `/images/:id/delete`: Usuwanie obrazka.

### Ścieżki związane z galeriami:

- `/galleries`: Przeglądanie listy galerii.
- `/galleries/add`: Formularz dodawania nowej galerii.
- `/galleries/:id/delete`: Usuwanie galerii.

## 4. Opis modeli wykorzystywanych w kolekcjach

### Model `User`

```javascript
const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const UserSchema = new Schema({
  first_name: { type: String, maxLength: 100 },
  last_name: { type: String, maxLength: 100 },
  username: { type: String, maxLength: 100 },
  password: { type: String }
});

module.exports = mongoose.model("User", UserSchema);

### Model `Gallery`

const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const GallerySchema = new Schema({
  name: { type: String, maxLength: 100, required: true },
  description: { type: String, maxLength: 200 },
  updated: { type: Date, default: Date.now() },
  user: { type: Schema.Types.ObjectId, ref: "User", required: true }
}, { collection: 'galleries' });

module.exports = mongoose.model("Gallery", GallerySchema);

### Model `Image`

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ImageSchema = new Schema({
  name: { type: String, required: true },
  description: { type: String },
  path: { type: String, required: true },
  gallery: { type: Schema.Types.ObjectId, ref: 'Gallery' },
  comments: [
    {
      text: String,
      date: { type: Date, default: Date.now }
    }
  ]
});

module.exports = mongoose.model('Image', ImageSchema);

### Model `comment`

const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const CommentSchema = new Schema({
  content: { type: String, required: true },
  author: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  image: { type: Schema.Types.ObjectId, ref: 'Image', required: true },
  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Comment', CommentSchema);


## 5.Opis konstrukcji aplikacji

Aplikacja składa się z kilku kluczowych komponentów:

- **app.js**: Główne wejście aplikacji, konfiguruje middleware, routingi i uruchamia serwer.
- **models/**: Zawiera definicje modeli MongoDB.
- **controllers/**: Zawiera logikę aplikacji obsługującą zapytania HTTP.
- **routes/**: Definiuje ścieżki URL i przypisuje je do odpowiednich kontrolerów.
- **views/**: Zawiera szablony Pug do renderowania dynamicznych stron HTML.
- **middleware/**: Zawiera middleware do autoryzacji i innych funkcji.

## Wykorzystane technologie

- **Node.js**: Środowisko uruchomieniowe JavaScript po stronie serwera.
- **Express.js**: Framework webowy dla Node.js.
- **MongoDB**: Baza danych NoSQL.
- **Mongoose**: ODM (Object Data Modeling) dla MongoDB.
- **Pug**: Silnik szablonów dla Node.js.
- **Passport**: Middleware do autoryzacji użytkowników.
- **Multer**: Middleware do obsługi przesyłania plików.